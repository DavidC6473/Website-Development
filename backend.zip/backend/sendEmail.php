<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require 'sendgrid-php/sendgrid-php.php';

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Create a new SendGrid email
$emailObject = new \SendGrid\Mail\Mail();
$emailObject->setFrom('d_cc@live.ie');
$emailObject->setSubject('New Contact Form Submission');
$emailObject->addTo('dcc6473@gmail.com'); // Replace with your email address
$emailObject->addContent(
    'text/plain',
    "Name: $name\nEmail: $email\nMessage: $message"
);

// Set your SendGrid API key
$apiKey = getenv('SENDGRID_API_KEY');

// Send the email
$sendgrid = new \SendGrid($apiKey);
try {
    $response = $sendgrid->send($emailObject);
    echo 'Email sent successfully';
} catch (Exception $e) {
    echo 'Failed to send email: ' . $e->getMessage();
}

